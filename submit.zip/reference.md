# Reference List

- Dataset Description: [https://www.kaggle.com/c/titanic/data](https://www.kaggle.com/c/titanic/data)

